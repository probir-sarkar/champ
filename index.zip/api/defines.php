<?php
define('INSTAGRAM_APP_ID', '423043692653490');
define('INSTAGRAM_APP_SECRET', '2d9368ebf27e72a8109b4e4f175ad87a');
define('INSTAGRAM_APP_REDIRECT_URI', 'https:champoffroad.herokuapp.com/api/');
