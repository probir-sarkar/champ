<style>
    .buttom-divider{
    padding-top: 5%;
    padding-bottom: 5%;
    border-top: 1px solid black;
    border-bottom: 1px solid black;
    box-shadow: inset 0 1px 0 0 rgb(255 255 255 / 8%);
}
</style>
<div class="container-fluid buttom-divider">
</div>
