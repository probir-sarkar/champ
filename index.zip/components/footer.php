 <style>
     .footer-shadow{
     box-shadow: inset 0 1px 0 0 rgb(255 255 255 / 8%);}
 </style>
 
 <footer class="d-flex footer-shadow">
        <div class="container-fluid">
            <div class="row d-flex justify-content-center mt-lg-2">
                <ul class="footer-menu mb-2">
                    <li class="mr-2"><a href="">EVENTS</a></li>
                    <li class="mr-2"><a href="">TICKETS</a></li>
                    <li class="mr-2"><a href="">SHOP</a></li>
                    <li class="mr-2"><a href="">CONTACT</a></li>
                </ul>
            </div>
            <div class="row footer-icon d-flex justify-content-center">
                <a href=""><i class="fab fa-facebook-square mx-4 h3"></i></a>
                <a href=""><i class="fab fa-twitter-square mr-4 h3"></i></a>
                <a href=""><i class="fab fa-youtube mr-4 h3"></i></a>
                <a href=""><i class="fab fa-instagram-square h3"></i></a>
            </div>
            <div class="row mb-5 mt-3">
                <img src="footer/LIVESTREAM_BANNER_19120.jpg" alt="">
            </div>
        </div>
    </footer>